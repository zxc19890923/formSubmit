import {Component, OnInit} from '@angular/core';
// 表单
import {FormControl, FormGroup, FormBuilder, ReactiveFormsModule} from "@angular/forms";

@Component({
    selector: 'app-my-form',
    templateUrl: './my-form.component.html',
    styleUrls: ['./my-form.component.css']
})
export class MyFormComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

    formSubmit(ctl) {
        console.log(ctl);
    }
}
